import java.util.Comparator;

/**
 * Comparator used by the priority queue which compares nodes based on their respective weights
 * 
 * @author David Al Baiaty Suarez 2474364A
 *
 */
public class MyComparator implements Comparator<NodeHuffman> {
	
	public int compare(NodeHuffman node1, NodeHuffman node2) {
		return Integer.compare(node1.getWeight(), node2.getWeight());
	}
}
