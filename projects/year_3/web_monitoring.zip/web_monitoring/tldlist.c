/*
 * Authorship statement - David Al Baiaty Suarez
 *
 * This is my own work and therefore is subject to copyright, this solution (or part of the solution) may be used if a link
 * to my github is explicitly provided in your work.
 *
 * Any external search conducted and resources used are from official documentation
 *
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "date.h"
#include "tldlist.h"


struct tldlist{
	TLDNode *root;
	Date *begin;
	Date *end;
	// size of tldlist
	long length;
	// number of succesful additions to the tldlist
	long counts;
};

struct tldnode{
	TLDNode *leftChild, *rightChild;
	char* tld;
	long counts;
};

struct tlditerator{
	TLDList *tld;
	int currentIndex;
	long length;
	// connects each node in this flatted version of the tldlist implementation
	TLDNode **nextNode;
};

/* List structure for storing counts against TLDs
 * constrained by begin and end Dates
 */
TLDList *tldlist_create(Date *begin, Date *end){
	TLDList *tldlist = (TLDList *)malloc(sizeof(TLDList));

	// if memory allocated correctly
	if(tldlist != NULL){
		// initialize root to NULL (prepared for adding nodes)
		tldlist->root = NULL;
		tldlist->begin = begin;
		tldlist->end = end;
		// initialize counts to 0 (no nodes added at this stage)
		tldlist->counts = 0;
		tldlist->length = 0;
		return tldlist;
	} // memory allocation failed so return NULL
	else{
		fprintf(stderr, "Unable to create TLD list\n");
		return NULL;
	}
}

/* Destroys list structure,
 * memory returned to heap
 */
void tldlist_destroy(TLDList* tld){
	if(tld != NULL) free(tld);
}

/*
 * Helper function to add the tld_name as a node in the BST
 * we require the TLDlist, tld_name and the node which is the root
 * static since we want to keep scope of the function within this file
 */
static TLDNode *add_node(TLDList* tld, char* tld_name, TLDNode* node){
        // CASE 1: NULL node, create a new node
        if (node == NULL){
                TLDNode *newNode = (TLDNode *)malloc(sizeof(TLDNode));
                if (newNode == NULL){
			fprintf(stderr, "Unable to create new node\n");
			return NULL;
		}
                // Initialize new node created
                newNode->tld = tld_name;
                newNode->leftChild = newNode->rightChild = NULL;
                newNode->counts = 1;
                // Update main tld
                tld->root = newNode;
                tld->length++;
                return newNode;
        }// CASE 2: tld_name < node->tld 
        else if (strcmp(tld_name, node->tld) < 0){
                node->leftChild = add_node(tld, tld_name, node->leftChild);
        }// CASE 3: tld_name > node->tld 
        else if (strcmp(tld_name, node->tld) > 0){
                node->rightChild = add_node(tld, tld_name, node->rightChild);
        }// CASE 4: tld_name == node->tld
        else{
                // Found node with same value, increment count for THIS node
                node->counts++;
                // free tld_name since we won't use it (duplicate)
                free(tld_name);
        }

	return node;
}

/* Inserting the element of TLD to the TLDList
 * iff Date provided valid (inside the range Date begin and Date end)
 * returns 1 if entry valid, else 0
 */
int tldlist_add(TLDList *tld, char *hostname, Date *d){
	// check if date (d) provided is valid
	if (date_compare(tld->begin,d) > 0 || date_compare(tld->end,d) < 0){
		fprintf(stderr, "Invalid date provided\n");
		return 0;
	}

	/* extraction of TLD from hostname (format: dd/mm/yyyy www.temp.TLD)
	 * where temp is the name of the site
	 * and TLD is either a 2 or 3 letter country code
	 */
	char* TLDFromHostname = strrchr(hostname, '.')+1; // +1, don't want to include '.'

	// Allocates memory and all letters from TLD to lower case
	char* tldForNode = (char *)malloc(sizeof(TLDFromHostname));
	strcpy(tldForNode, TLDFromHostname);
	for (int i=0; i<strlen(tldForNode); i++) tldForNode[i] = tolower(tldForNode[i]);
		
	// Checks if the length of tld is not within a valid range
	if (strlen(tldForNode) > 3 || strlen(tldForNode) < 2){
		fprintf(stderr, "Invalid length %lu for a tld\n", strlen(tldForNode));
		free(tldForNode);
		return 0;
	}
	// add new tld to the tld BST
	tld->root  = add_node(tld, tldForNode, tld->root);
	// checks if node added correctly to tldlist	
	if (tld->root != NULL){
	       tld->counts++;
	       return 1;
	}else return 0;
}

/* returns number of succesful tldlist_add() calls */
long tldlist_count(TLDList *tld){
	return tld->counts;
}

/* helper method for postorder traversal of the BST (TLDList) */
static void postOrderTraversal(TLDIterator *iter, TLDNode *node, int *tempIndex){
        if (node == NULL) return;

        postOrderTraversal(iter, node->leftChild, tempIndex);
	postOrderTraversal(iter, node->rightChild, tempIndex);
	// store the current node into the double pointer nextNode
	*(iter->nextNode + (*tempIndex)++) = node;
}

/* creates iterator over TLDList */
TLDIterator *tldlist_iter_create(TLDList *tld){
	TLDIterator *iter = (TLDIterator *)malloc(sizeof(TLDIterator));
	// if memory allocation fails
	if (iter == NULL){
		fprintf(stderr, "Unable to create iterator\n");
		return NULL;
	}
	iter->tld = tld;
	// initialize to 0 and get length from tld since we are creating a new iterator
	iter->currentIndex = 0;
	iter->length = tld->length;
	// allocates memory to nextNode (size of the BST with all nodes already present)
	iter->nextNode = (TLDNode **)malloc(iter->length * sizeof(TLDNode*));
	// if memory allocation fails, destroy iterator and return null
	if (iter->nextNode == NULL){
		tldlist_iter_destroy(iter);
		fprintf(stderr, "Unable to create iterator\n");
		return NULL;
	}else{
		// temporary index to increment positions for postorder traversal
		int tempIndex = 0;
		postOrderTraversal(iter, iter-> tld->root, &tempIndex);
		return iter;
	}
}

/* returns a pointer to the next element in the list if element found, NULL otherwise */
TLDNode *tldlist_iter_next(TLDIterator *iter){
	// check if we are at the end of the tld
	if (iter->currentIndex == iter->length) return NULL;
	int temp = iter->currentIndex++;
	// return pointer to next node
	return *(iter->nextNode + temp);
}

/* destroys iterator specified by 'iter' */
void tldlist_iter_destroy(TLDIterator *iter){
	int index = 0;
	while (index < (iter->length)){
		/* cast to type TLDNode* and free tld of type char*
		 * since this was dynamically allocated using
		 * malloc when the node was created
		 */
		free(((TLDNode *)*(iter->nextNode + index))->tld);
		free(*(iter->nextNode + index));
		index++;
	}
	// after freeing all nodes inside nextNode, free nextNode and iter
	free(iter->nextNode);
	free(iter);
}

/* returns tld associated with the TLDNode */
char *tldnode_tldname(TLDNode *node){
	return node->tld;
}

/* returns number of times that a log entry for tld  was added to list*/
long tldnode_count(TLDNode *node){
	return node->counts;
}

