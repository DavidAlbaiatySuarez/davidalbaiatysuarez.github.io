/*
 * Authorship statement - David Al Baiaty Suarez
 *
 * This is my own work and therefore is subject to copyright, this solution (or part of the solution) may be used if a link
 * to my github is explicitly provided in your work.
 *
 * Any external search conducted and resources used are from official documentation
 *
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "date.h"

#define DELIMITER "/"

struct date{
	int day;
	int month;
	int year;
};

/* Create object of type Date from a string */
Date *date_create(char *datestr){

        Date *date = (Date *)malloc(sizeof(Date));

	// memory allocation failed
	if(date == NULL){
		fprintf(stderr, "Unable to create date\n");
		return NULL;
	}	

	// Get day from string
	char *token = strtok(datestr, DELIMITER);
	int day = atoi(token); // atoi() to convert from char to int
	// Get month from string 
	token = strtok(NULL, DELIMITER);
	if (token == NULL){
		fprintf(stderr, "Wrong format: month is NULL\n");
                free(date);
                return NULL;
	}
	int month = atoi(token);
	// Get year from string
        token = strtok(NULL, DELIMITER);
        if (token == NULL){
		fprintf(stderr, "Wrong format: year is NULL\n");
                free(date);
                return NULL;
	}
	int year = atoi(token);

	// Loads appropiate data to Date
	date->day = day;
	date->month = month;
	date->year = year;

	// returns the pointer to the newly created date structure
	return date;
}

/* 
 * Duplicates the data structure provided
 * if memory allocation fails, returns NULL
 */
Date *date_duplicate(Date *d){
	Date *date_duplicate = (Date *)malloc(sizeof(Date));
	// If memory allocated correctly, duplicate
	if (date_duplicate != NULL){
		date_duplicate->day = d->day;
		date_duplicate->month = d->month;
		date_duplicate->year = d->year;
		return date_duplicate;
	}
	// Memory allocation failed so return NULL
	fprintf(stderr, "Unable to create a duplicate of date\n");
	return NULL;
}


/* Compares two dates
 * Let <0 = -1, >0 = 1
 */
int date_compare(Date *date1, Date *date2){
	// First compare the years (trivial)
	if(date1->year < date2->year) return -1;
	else if (date1->year > date2->year) return 1;
	// Now compare the months and days since years are the same 
	else
		if (date1->month < date2->month) return -1;
		else if (date1->month > date2->month) return 1;
		else if (date1->day < date2->day) return -1;
		else if (date1->day > date2->day) return 1;
		// Dates are identical
		else return 0;
}

/* Returns any storage associated with 
 * the argument of type Date to the system
 */
void date_destroy(Date *d){
	if(d != NULL) free(d);
	// Clearly  if d is NULL no memory to deallocate (do nothing)
}


