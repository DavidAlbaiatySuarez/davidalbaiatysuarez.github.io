#Implement an autocomplete system. That is, given a query string s and a set of all possible query strings,
#return all strings in the set that have s as a prefix.

#For example, given the query string de and the set of strings [dog, deer, deal], return [deer, deal].

prefixes = [ "de", "ex", "in"]
new_prefixes = []

words = [ "dog", "dear", "deal", "debugg", "exhale", "explosion", "inaction", "invisible"]
final_words = []

def main():
    prefixe = input("Enter a prefixe: ")

    for letter in prefixe:
        new_prefixes.append(letter)

    for word in words:
        if word[0] == new_prefixes[0]:
            if word[1] == new_prefixes[1]:
                final_words.append(word)
    return final_words

print(main())

#Only works if prefixe consists of two letters.
                
                
    
