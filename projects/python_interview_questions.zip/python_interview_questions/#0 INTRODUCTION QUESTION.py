#Return a new sorted merged list from K sorted lists, each with size N.

#For example, if we had [[10, 15, 30], [12, 15, 20], [17, 20, 32]],
#the result should be [10, 12, 15, 15, 17, 20, 20, 30, 32].

from types import *

def merge_list(k):
    new_list = []

    for x in k:
        if isinstance(x, list):
            new_list.append(x)
        else:
            new_list.append(x)
    return new_list

print(merge_list([[10, 15, 30], [12, 15, 20], [17, 20, 32]]))
    


            
