#Given a list of numbers and a number k,
#return whether any two numbers from the list add up to k.

#For example, given [10, 15, 3, 7] and k of 17, return true since 10 + 7 is 17.

def main(k):
    my_list = [10, 15, 3, 7]
    for num1 in my_list:            #Having two for loops means that we want two numbers
        for num2 in my_list:
            if num1 + num2 == k:
                return [num1, num2]    #Returns the two numbers inside a list

#Following code to run program:
#print(main(25)) #Expected result [10, 15]
#print(main(10)) #Expected result [3, 7]

#--------------------------------------------------------------------------------------------------------------

#Now we will do the same as above but we will now return any three numbers from the list

def main(k):
    my_list = [10, 15, 3, 7, 2, 4, 5]
    for num1 in my_list:            
        for num2 in my_list:
            for num3 in my_list:
                if num1 + num2 + num3 == k and num1 != num2 and num2 != num3: #So that we don´t repeat numbers
                    return [num1, num2, num3]

#Following code to run program:
#print(main(30)) #Expected result [10, 15, 5]



