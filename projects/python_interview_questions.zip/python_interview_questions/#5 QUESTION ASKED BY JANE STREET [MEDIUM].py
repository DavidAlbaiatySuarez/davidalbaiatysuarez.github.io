#cons(a, b) constructs a pair, and car(pair) and cdr(pair) returns the first and last element of that pair.
#For example, car(cons(3, 4)) returns 3, and cdr(cons(3, 4)) returns 4.

#This implementation of cons was alreay given in the question:

def cons(a, b): #the cons function returns a function, not a value. You have to call the result again
    def pair(f):
        return f(a, b)
    return pair

#Implement car and cdr. This come from Lisp(a programming language)
#According to wikipedia:A cons cell is composed of two pointers;
                       #the car operation extracts the first pointer, and the cdr operation extracts the second.

def car(cons): #We get the value of a,b from the function cons
    return cons(lambda a, b: a) #The power of lambda is better shown when we use it as an anonymous function
                                #lambda arguments : expressions
                                #In this case we have two arguments, a and b, but we only want a
def cdr(cons):
    return cons(lambda a, b: b) #In here we want whatever value b is.

#Following code to run program:
#print(car(cons(3, 4)))
#print(cdr(cons(3, 4)))

#You can aswell do it without using lambda:

def cons(a, b): #pair() is an inner function of cons()
    def pair(f):
        return f(a, b)
    return pair

def car(f):
    def left_element(a, b):
        return a
    return f(left_element)

def cdr(f):
    def right_element(a, b):
        return b
    return f(right_element)

#Following code to run the program:
#print(car(cons(3, 4)))
#print(cdr(cons(3, 4)))


