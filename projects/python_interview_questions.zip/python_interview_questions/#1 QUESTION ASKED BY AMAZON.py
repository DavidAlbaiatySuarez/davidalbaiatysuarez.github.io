#Python Hard interview questions

#Exercise 1: Question asked by Amazon

#There's a staircase with N steps, and you can climb 1 or 2 steps at a time.
#Given N, write a function that returns the number of unique ways you can climb the staircase.
#The order of the steps matters.

#For example, if N is 4, then there are 5 unique ways:
#1, 1, 1, 1
#2, 1, 1
#1, 2, 1
#1, 1, 2
#2, 2

def staircase(n):
    if n <= 1:
        return 1
    else: #Don´t really need an else but looks better.
        return staircase(n - 1) + staircase(n - 2) #This is just the Fibonacci sequence:
                                                   #f(n) = f(n - 1) + f(n + 2)
                                                   #Each number in a sequence is the sum of the previous:
                                                   #1,1,2,3,5,8...

#We can do it a lot faster by just computing iteratively:
def staircase(n):
    a, b = 1, 2 #a = 1, b = 2
    for _ in range(n - 1): # _  is just a temporal value meaning it is not important.
        a, b = b, a + b # a = b, b = a + b as right evaluated before left
                        # 1, 2 = 2, 3
                        # 2, 3 = 3, 5
                        # 3, 5 = 5, 8
    return a # 2, 3, 5, 8.. so if n = 3, [2] = 3  if n = 5, [4] = 8     #So Fibonnaci sequence!!

        
#---------------------------------------------------------------------------------------------------------------------

#What if, instead of being able to climb 1 or 2 steps at a time, you could climb any number from a set of positive integers X?
#For example, if X = {1, 3, 5}, you could climb 1, 3, or 5 steps at a time. Generalize your function to take in X.

def staircase(n, x): #x will be a list of numbers
    total = 0 #Intialize total
    if n >= 0:
        for i in range(0, len(x)):
            total += n - x[i] #This is again Fibonacci sequence but with a twist as we don´t know x
                              #f(n) = f(n - x[0]) + f(n - x[1]) + f(n - x[2]) .... 
    return "Number of unique ways you can climb is %d" % total
                 
#Following code to run the program:
#print(staircase(4, [1, 2, 3, 4] ))
