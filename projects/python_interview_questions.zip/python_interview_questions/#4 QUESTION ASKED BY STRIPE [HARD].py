#Given an array of integers, find the first missing positive integer in linear time and constant space.
#In other words, find the lowest positive integer that does not exist in the array.
#The array can contain duplicates and negative numbers as well.

#For example, the input [3, 4, -1, 1] should give 2. The input [1, 2, 0] should give 3.

def missing_number(A):

    max_num = max(A)#Storing maximum value
    
    if max_num < 1: #In case all the numbers stored in A are negative
        return 1 #So the biggest positve number will be always 1

    if len(A) == 1: #In case the list only has 1 element
        if A[0] == 1:  #You could also write this as return 2 if A[0] == 1 else 1
            return 2
        else:
            return 1

    l = [0] * max_num #Creates an array "l" with the amount of 0's correspoding to the length of array "A"

    for i in range(len(A)): 
        if A[i] > 0:                
            if l[A[i] - 1] != 1: #Changing the value status at the index of our list 
                l[A[i] - 1] = 1 

    for i in range(len(l)):
        if l[i] == 0:  
            return i + 1
            #In case all values are filled between 1 and m 
    return i + 2     
   
#Following code to run program:
print(missing_number([0,2,1])) #Expected result: 3
print(missing_number([0,2,1,4])) #Expected result: 3
print(missing_number([0, 10, 2, -10, -20])) #Expected result: 1
print(missing_number([3])) #Expected result: 1




  






    
