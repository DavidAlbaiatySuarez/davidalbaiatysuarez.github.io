#Given an array of integers, return a new array such that each element at index i of the new array
#is the product of all the numbers in the original array except the one at i.

#For example, if our input was [1, 2, 3, 4, 5], the expected output would be [120, 60, 40, 30, 24].
#If our input was [3, 2, 1], the expected output would be [2, 3, 6].

#My first attempt, instead of multiplying each element it is adding it.
def main():
    n = [1, 2, 3, 4, 5]
    new_array = []

    for i in range(len(n)):
        total = sum(n) - n[i]
        new_array.append(total)
    return new_array

#print(main())

#-------------------------------------------------------------------------------------------------

#My second attempt, it now does what the problem asks; however, it doesn´t look efficient enough. But hey it works.
def main(numbers):
    new_array = []
    total = 1

    for num in numbers:
        total *= num      #With this we find the total product of the numbers in the list

    for i in numbers:
        cal = total / i   #By dividing the numbers we take away the one at i
        new_array.append(cal)
    return new_array #Returns the new array with appropiate numbers

#Following code to run program:
#print(main([1, 2, 3, 4, 5])) #Expected result [120, 60, 40, 30, 24]
#print(main([3, 2, 1])) #Expected result [2, 3, 6]

#--------------------------------------------------------------------------------------------------

#Bonus question: do the problem without dividing: 



