#Run length encoding

string = 'kkkddaasstttdddd'
temp = ''
encoding = ''
total = 1

for element in string:

    if element != temp: 
        if temp: #If temp not null, first run will not add the next line to encoding
            #as temp IS NULL at first
            encoding += str(total) + temp
        total = 1
        temp = element

    else: #If element = temp, continue adding to total
        total += 1
else: #Not coding an else here will result in the last character being ignored.
    encoding += str(total) + temp

print(encoding)
