import requests
import json

#Define url 
url = "https://api.travelex.net/salt/config/multi?key=Travelex&site=%2Fvirgin&options=abhikzl"

r = requests.get(url)
statusCode = r.status_code          
assert statusCode == 200, "error to return result"

data = json.loads(r.text) #Loading all the data as a json string
#The following is a way to pretty print the dictionary and finding out what you want
#print(json.dumps(data, sort_keys = True, indent =4)) 

exchange_rates = data['rates']['rates']

#Function to print all the exchange rates for each country
def AllExchangeRates():
    for item in exchange_rates:
        print("{}, {}".format(item, exchange_rates[item]))

#Function to convert x pounds to any world currency
def CurrencyConverter(currency, quantity):
    #From pound to x currency
    for item in exchange_rates:
        if item == currency:
            base = exchange_rates[item] #Same thing as data["rates"]["rates"]["item"]
    exchange = quantity * base
    return exchange

#Function to display all the codes for different currencies
def DisplayWorldCurrencies():
    display_country = data["widget"]["items"]
    for item in display_country:
        for i in item:
            if i == "countryName":
                print(item[i],end="|")
            if i == "countryCode":
                print(item[i],end="|: ")
            if i == "currencyCode":
                print(item[i])

print("Last time data was modified %s" % (data["rates"]["lastModified"]))

displayCountryCode = input("Do you wish to display all countries currency codes?: ").lower()

if displayCountryCode == "yes":
    DisplayWorldCurrencies()

currency = input("Enter currency you wish to exchange pounds for: ").upper()
quantity = float(input("Enter amount of money: "))
print(CurrencyConverter(currency, quantity))




