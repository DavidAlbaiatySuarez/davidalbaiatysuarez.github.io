#Write a Python program of recursion of a list
#Test Data: [1,2,[3,4],[5,6]]
#Expected result: 21

def RecursiveList(list_, total=0):
    for element in list_: #Note that the elements will be 1, [3,3], 4
        if type(element) == type([]): #If there is a nested list
            total += RecursiveList(element)# The element will be [3,3]
                                       #we will then do recursion on it
        else:
            total += element
    return total

print(RecursiveList([1,[3,3,[1,2]],4]))
