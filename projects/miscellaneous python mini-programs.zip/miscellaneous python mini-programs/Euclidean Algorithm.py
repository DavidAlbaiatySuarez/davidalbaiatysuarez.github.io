
#Euclidean algorithm using recursion and lowest common multiple

def EuclideanAlgorithm(a,b,temp=None):
    q = b // a
    r = b % a
    
    if r == 0:
        print()
        return "The hcf is %d" % (temp)
    else:
        print("%d = %d.%d + %d" % (b, q, a, r))
        b,a=a,r
        temp = r
        return EuclideanAlgorithm(a,b,temp=r)

def LowestCommonMultiple(a,b):
    hcf = EuclideanAlgorithm(a,b)
    return "The lcm is %d" % ((a * b) / int(hcf[11:])) #hcf[11:] to get the number from the string above


def testing():
    assert EuclideanAlgorithm(1,1) == "The hcf is 1", print("It should be 1")
    assert EuclideanAlgorithm(1428,5817) == "The hcf is 21", print("It should be 21")
    assert EuclideanAlgorithm(86,100) == "The hcf is 2", print("It should be 2")
    assert LowestCommonMultiple(1428,5817) == "The lcm is 395556", print("It should be 395556")
    print("ALL OK")


print(EuclideanAlgorithm(43560,24750,temp=1))
#testing()
