#Factorial calculator

def FactorialCalculator(n,total=1):
    if n == 1:
        return total
    elif n < 0:
        return "Number needs to be a positive integer"
    else:
        total *= n
        return FactorialCalculator(n-1,total) #Returns the new total

print(FactorialCalculator(4))

