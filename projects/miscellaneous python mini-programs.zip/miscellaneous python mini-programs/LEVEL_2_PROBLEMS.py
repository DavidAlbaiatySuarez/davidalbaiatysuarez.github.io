#--------------------Program1----------------------

#Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. 
#The element value in the i-th row and j-th column of the array should be (i*j).
#Given the values 3, 5 the output of the program should be:
#[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]]

array = [[row*col for col in range(5)] for row in range(3)]

#print(array)

#-------------------Program2----------------------

#Write a program that accepts a comma separated sequence of words as input 
#and prints the words in a comma-separated sequence after sorting them alphabetically.

sequence_of_words = input("Enter a sequence of words: ")
separating_words = ", ".join(sorted([i for i in sequence_of_words.split(",")]))

#print(separating_words)

#--------------------Program3---------------------

#Write a program that accepts sequence of lines as input 
#and prints the lines after making all characters in the sentence capitalized.

lines_of_data = []
_input = None
while _input != "q":
    _input = input()
    if _input != "q":
        lines_of_data.append(_input.upper())

#print("\n".join(lines_of_data))
