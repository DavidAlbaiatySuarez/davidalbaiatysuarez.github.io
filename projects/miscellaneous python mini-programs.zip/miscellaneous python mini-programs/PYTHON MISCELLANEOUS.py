#Python exercises miscellaneous     

#Exercise 1: Write a Python program to find smallest and largest word in a given string.

def smallest_largest_words(str1):
    word = ""
    all_words = []
    str1 = str1 + " " #Without this it will print only the first word of the sentence
    for i in range(len(str1)):
        if(str1[i] != " "):
            word += str1[i]  
        else:
            all_words.append(word)  
            word = "" #We initialize again word so that the previous name doesn't output with new word

    small = large = all_words[0]

    for word in range(len(all_words)):
        if len(small) > len(all_words[word]):
            small = all_words[word]
        elif len(large) < len(all_words[word]):
            large = all_words[word]
        elif len(small) == len(all_words[word]) or len(large) == len(all_words[word]):
            pass #if two words are same length, it will always output the first word as smallest.
    return "Smallest word: %s" % small, "Largest word: %s" % large
    
#Following code to run program:

#sentence = input("Enter: ")
#print(smallest_largest_words(sentence))

#-----------------------------------------------------------------------------------------------

#Exercise 2: Write a Python program to count repeated characters in a string.

def repeated_characters(str1):
    total = 0
    my_list = []
    repeated_list = []

    for char in str1:
        if char in my_list and char != " ": #It will not count a space as a repeated character
            total += 1
            repeated_list.append(char)
            my_list.append("*") #Just to make sure program is working correctly
        elif char not in my_list or char == " ": 
            my_list.append(char)
    return "From %s the letters %s were repeated %d times in total." % ("".join(my_list), ",".join(repeated_list), total)

#Following code to run program:

#print(repeated_characters("Juntos por el si"))#It works correctly and outputs 2 repeated characters
#print(repeated_characters("Violence must suffice then"))
  
#-------------------------------------------------------------------------------------------------

#Exercise 3: Python function to create a list where the values are square of numbers between 1 and 30(both included).

def square_list():
    new_list = []
    for number in range(1, 31):
        cal = number ** 2
        new_list.append(cal)
    return new_list

#Following code to run program:
#print(square_list())

#--------------------------------------------------------------------------------------------------

#Exercise 4: Python program to check if a given integer is a power of 2.

def power_finder(x):
    y = x #Did this to print the initial value of x in the return string
    while x != 1:
        if x % 2 != 0: #For x to be a power of 2, it must divide by 2 until it gives 1
            return "%d is not a power of 2" % (x)
        x = x / 2 
    if x == 1:
        return "%d is a power of 2" % (y)

#Following code to run program:
#print(power_finder(16)) #It will return True
#print(power_finder(15)) #It will return False

#----------------------------------------------------------------------------------------------------

#Exercise 5: Python program to check if an integer is the power of another integer. Eg: 16, 2 return True

def power_integer(x, y):
    while x != 1:
        if x % y != 0:
            return "False"
        x = x / y
    if x == 1:
        return "True"
#You could aswell say while x % y == 0:
                      #   x = x / y
                      #return x == 1

#Following code to run program:
#print(power_integer(8, 2))
#print(power_integer(12, 2))

#----------------------------------------------------------------------------------------------------

#Exercise 6: Python program to find the missing number inside a list. Eg: [1, 2, 4, 5] num_missing = 3

def missing_number(numbers):
    missing_num = sum( _ for _ in range(numbers[0], numbers[-1] + 1)) - sum(numbers)
    return "The missing number is %d." % (missing_num)

#Following code to run program:
#print(missing_number([1, 3, 4, 5, 6])) #This program will only work if only 1 missing number

def missing_number(numbers):
    completed_list = []
    for number in range(numbers[0], numbers[-1] + 1): # +1 to print last number in list
        if number not in numbers:
            completed_list.append(number)
        else:
            completed_list.append(number)
    return completed_list

#Following code to run program:
#print(missing_number([1, 2, 4, 6])) #This will work even if multiple numbers missing

#---------------------------------------------------------------------------------------------------

#Exercise 7: Finding the square root of a number, difficult way

def my_sqrt(x):
    if x<2:
        return x
    left = 1
    right = int(x/2)+1
    while left <= right:
        mid = int((left+right)/2)
        if mid * mid == x:
            return mid
        if mid * mid > x:
            right = mid - 1
        else:
            left = mid+1
     
#Following code to run program:
#print(my_sqrt(16))

#------------------------------------------------------------------------------------------------------

#Exercise 8: Check if a sequence of numbers are in arithmetic progression

def arithmetic_progression(numbers):
    diff = numbers[1] - numbers[0] #The difference between values needs to be constant
    for i in range(numbers[0], numbers[-1] + 1): #Both initial and final values inclusive
        if not numbers[i + 1] - numbers[i] == diff:
            return "Not in arithmetic progresion"
        else:
            return "It is in an arithmetic progression with a common difference of %d" % (diff)

#Following code to run program:
#print(arithmetic_progression([2, 4, 6, 8]))

#------------------------------------------------------------------------------------------------------

#Exericse 9: Python program where you take any positive integer n, if n is even, divide it by 2 to get n / 2.
#If n is odd, multiply it by 3 and add 1 to obtain 3n + 1. Repeat the process until you reach 1.
#Eg: Input = 12, Output : [12, 6.0, 3.0, 10.0, 5.0, 16.0, 8.0, 4.0, 2.0, 1.0]
#This is known as the Collatz conjecture

def collatz_conjecture(x):
    new_list = [x] #We initialize the list with the value inputed by the user
    while x != 1:
        if x % 2 == 0:
            x = x /2
        else:
            x = (x * 3) + 1
        new_list.append(x) #Whatever value is x always add to new_list
    return new_list

#Following code to run program:
#print(collatz_conjecture(12)) #This is know as the Collatz conjecture:
                      #no matter what value of n, the sequence will always reach 1.

#------------------------------------------------------------------------------------------------------

#Exercise 10: Check if a string is an anagram of another string
#Anagram is a direct word switch or word play. Eg: "anagram", "nagaram" return True

def anagram(x, y):
    if sorted(x) == sorted(y): #sorts both string into alphabetic order
       return "This is an anagram"
    else:
        return "This is not an anagram"
        
#Following code to run program:
#print(anagram("anagram", "nagaram")) #Expected result: True
#print(anagram("anagram", "nataram")) #Expected result: False

#-------------------------------------------------------------------------------------------------------

#Exericse 11: Python program to computes the sum of the digits of the number 220
#Eg: 2 ** 10 = 1024 and the sum of its digits is 1 + 0 + 2 + 4 = 7

def sum_of_digits(x, y):
    total = 0
    cal = str(x ** y) #I allow the user to enter both numbers.
    numbers = []
    for element in cal:
        total += int(element)
        numbers.append(element)
    return "The sum of the digits %s is %d" % (numbers, total)
    
print(sum_of_digits(2, 20)) #Expected result is 31

#------------------------------------------------------------------------------------------------------


        



    
        
        








        
    

