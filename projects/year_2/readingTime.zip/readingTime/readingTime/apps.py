from django.apps import AppConfig


class ReadingtimeConfig(AppConfig):
    name = 'readingTime'
